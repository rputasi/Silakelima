import React, { useState, useEffect, useRef, useCallback } from 'react';
import type { Chat } from '@google/genai';
import { MOCK_TRANSACTIONS } from '../constants';
import { createChat } from '../services/geminiService';
import type { ChatMessage } from '../types';

const UserIcon: React.FC = () => (
    <div className="w-9 h-9 rounded-full bg-brand-primary flex-shrink-0 flex items-center justify-center font-bold text-white shadow-md">
        A
    </div>
);

const AIIcon: React.FC = () => (
    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-secondary to-brand-accent flex-shrink-0 flex items-center justify-center shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-white">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
    </div>
);

const TypingIndicator: React.FC = () => (
    <div className="flex items-center justify-center space-x-1.5">
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
    </div>
)

const AIPage: React.FC = () => {
    const [chat, setChat] = useState<Chat | null>(null);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        setIsLoading(true);
        try {
            const chatSession = createChat(MOCK_TRANSACTIONS);
            setChat(chatSession);
            setMessages([]);
        } catch (e: any) {
            setError(e.message || "Gagal memulai sesi chat AI.");
        } finally {
            setIsLoading(false);
        }
    }, []);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading]);

    const handleSend = useCallback(async (prompt?: string) => {
        const query = prompt || input;
        if (!query.trim() || isLoading || !chat) return;

        setIsLoading(true);
        setError('');
        const userMessage: ChatMessage = { role: 'user', text: query };
        setMessages(prev => [...prev, userMessage]);
        setInput('');

        try {
            const stream = await chat.sendMessageStream({ message: query });
            
            setMessages(prev => [...prev, { role: 'model', text: '' }]);

            for await (const chunk of stream) {
                const chunkText = chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMessage = newMessages[newMessages.length - 1];
                    if (lastMessage.role === 'model') {
                        lastMessage.text += chunkText;
                    }
                    return newMessages;
                });
            }
        } catch (err) {
            console.error(err);
            const errorMessage: ChatMessage = { role: 'model', text: 'Maaf, terjadi kesalahan saat berkomunikasi dengan AI. Silakan coba lagi.' };
            setMessages(prev => {
                const lastMessage = prev[prev.length - 1];
                if (lastMessage.role === 'model' && lastMessage.text === '') {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = errorMessage;
                    return newMessages;
                }
                return [...prev, errorMessage];
            });
        } finally {
            setIsLoading(false);
        }
    }, [input, isLoading, chat]);

    const suggestedPrompts = [
        "Berapa total pajak yang terkumpul dari data yang ada?",
        "Industri mana yang membayar pajak paling banyak?",
        "Identifikasi 3 transaksi anomali dengan nilai terbesar.",
        "Buatkan ringkasan tren transaksi bulan ini."
    ];

    return (
        <div className="flex flex-col h-full bg-dark-bg text-dark-text-primary">
            <div className="flex-1 flex flex-col overflow-hidden bg-dark-card border-dark-border md:rounded-2xl m-0 md:m-4 md:shadow-2xl md:shadow-black/20">
                <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
                    {messages.length === 0 && !isLoading && !error && (
                        <div className="text-center text-dark-text-secondary flex flex-col justify-center items-center h-full">
                            <div className="p-4 bg-gradient-to-br from-brand-secondary to-brand-accent rounded-full mb-4">
                                <AIIcon />
                            </div>
                            <h2 className="text-2xl font-bold text-dark-text-primary">Asisten AI Fiskal</h2>
                            <p className="text-md mt-2">Mulai percakapan, atau pilih salah satu saran di bawah.</p>
                            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl mx-auto w-full">
                                {suggestedPrompts.map(p => (
                                    <button
                                        key={p}
                                        onClick={() => handleSend(p)}
                                        className="p-3 bg-dark-bg border border-dark-border rounded-lg text-sm text-left hover:border-brand-primary hover:bg-dark-card-hover transition-colors duration-200"
                                    >
                                        {p}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex items-start gap-3 w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.role === 'model' && <AIIcon />}
                            <div className={`max-w-xl p-3 px-4 rounded-2xl shadow-md ${msg.role === 'user' ? 'bg-brand-primary text-white rounded-br-none' : 'bg-dark-bg text-dark-text-primary rounded-bl-none'}`}>
                                <div
                                    className="prose prose-invert prose-sm max-w-none text-dark-text-primary whitespace-pre-wrap font-sans"
                                    dangerouslySetInnerHTML={{ __html: msg.text.replace(/\n/g, '<br />') }}
                                >
                                </div>
                            </div>
                            {msg.role === 'user' && <UserIcon />}
                        </div>
                    ))}
                    {isLoading && messages[messages.length - 1]?.role === 'user' && (
                       <div className="flex items-start gap-3 justify-start">
                         <AIIcon />
                         <div className="max-w-xl p-3 px-4 rounded-2xl shadow-md bg-dark-bg text-dark-text-primary rounded-bl-none">
                            <TypingIndicator />
                         </div>
                       </div>
                    )}
                    {error && <div className="text-red-400 text-center p-4 bg-red-900/20 rounded-lg">{error}</div>}
                    <div ref={messagesEndRef} />
                </div>

                <div className="p-4 border-t border-dark-border bg-dark-card">
                    <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex items-center gap-3">
                         <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Ketik pertanyaan Anda di sini..."
                            className="flex-grow py-2.5 px-4 text-dark-text-primary bg-dark-bg border border-dark-border rounded-lg focus:outline-none focus:ring-1 focus:ring-brand-primary transition-all"
                            disabled={isLoading}
                        />
                        <button
                            type="submit"
                            className="p-3 font-semibold text-white bg-brand-primary rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-card focus:ring-brand-primary disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-brand-primary transition-colors"
                            disabled={isLoading || !input.trim()}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                              <path d="M3.478 2.404a.75.75 0 0 0-.926.941l2.432 7.905H13.5a.75.75 0 0 1 0 1.5H4.984l-2.432 7.905a.75.75 0 0 0 .926.94 60.519 60.519 0 0 0 18.445-8.986.75.75 0 0 0 0-1.218A60.517 60.517 0 0 0 3.478 2.404Z" />
                            </svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default AIPage;