import React, { useState, useMemo } from 'react';
import StatCard from './StatCard';
import TransactionsTable from './TransactionsTable';
import AIAssistant from './AIAssistant';
import AIInsights from './AIInsights';
import Charts from './Charts';
import { MOCK_TRANSACTIONS } from '../constants';
import type { Stat } from '../types';

const ChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H9a2 2 0 01-2-2V5z" />
  </svg>
);

const CurrencyDollarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01M12 6v-1.6c0-.497.403-.9.9-.9h1.2c.497 0 .9.403.9.9V6m-3.2 9.401A4.5 4.5 0 018 16.5V13a2.5 2.5 0 012.5-2.5h3A2.5 2.5 0 0116 13v3.5a4.5 4.5 0 01-1.8 3.401" />
  </svg>
);

const UsersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 016-6h6a6 6 0 016 6v1h-3M15 21a3 3 0 01-3 3H9a3 3 0 01-3-3m15-12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const GlobeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h8a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.834 16.17A9.003 9.003 0 0012 21a9.003 9.003 0 004.166-4.83M12 3a9 9 0 00-7.834 4.83m15.668 0A9 9 0 0112 3z" />
    </svg>
);


const Dashboard: React.FC = () => {
    const [transactions] = useState(MOCK_TRANSACTIONS);

    const stats: Stat[] = useMemo(() => {
        const totalTax = transactions.reduce((acc, t) => acc + t.pajakAPT, 0);
        const totalVolume = transactions.reduce((acc, t) => acc + t.nominalTransaksi, 0);
        const ubiRecipients = 203_450_000; // Mock data
        const uhcCoverage = 290_000_000; // Mock data

        return [
            {
                title: 'Total Pajak APT Terkumpul',
                value: `Rp ${totalTax.toLocaleString('id-ID')}`,
                change: '+1.2% vs kemarin',
                changeType: 'increase',
                icon: <CurrencyDollarIcon className="w-8 h-8 text-white" />,
            },
            {
                title: 'Total Volume Transaksi',
                value: `Rp ${totalVolume.toLocaleString('id-ID')}`,
                change: '+5.4% vs kemarin',
                changeType: 'increase',
                icon: <ChartBarIcon className="w-8 h-8 text-white" />,
            },
            {
                title: 'Estimasi Penerima UBI',
                value: ubiRecipients.toLocaleString('id-ID'),
                change: 'Target 75%',
                icon: <UsersIcon className="w-8 h-8 text-white" />,
            },
            {
                title: 'Jangkauan UHC',
                value: uhcCoverage.toLocaleString('id-ID'),
                change: 'Target 100%',
                icon: <GlobeIcon className="w-8 h-8 text-white" />,
            },
        ];
    }, [transactions]);

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-dark-text-primary">
              Selamat Datang, <span className="bg-gradient-to-r from-brand-primary to-brand-secondary text-transparent bg-clip-text">Analis!</span>
            </h2>
            
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
                {stats.map((stat, index) => (
                    <StatCard key={index} {...stat} />
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-3 bg-dark-card border border-dark-border rounded-xl p-4 md:p-6 shadow-lg">
                   <Charts transactions={transactions} />
                </div>
                <div className="lg:col-span-2 flex flex-col gap-6">
                   <AIInsights transactions={transactions} />
                   <AIAssistant transactions={transactions}/>
                </div>
            </div>

            <div className="bg-dark-card border border-dark-border rounded-xl shadow-lg">
                <TransactionsTable transactions={transactions} />
            </div>
        </div>
    );
};

export default Dashboard;