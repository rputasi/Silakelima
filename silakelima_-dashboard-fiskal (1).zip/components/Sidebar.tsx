import React from 'react';

interface IconProps extends React.SVGProps<SVGSVGElement> {
  // No additional props
}

const HomeIcon: React.FC<IconProps> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const TransactionIcon: React.FC<IconProps> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
  </svg>
);

const ChartIcon: React.FC<IconProps> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H9a2 2 0 01-2-2V5z" />
  </svg>
);

const AIIcon: React.FC<IconProps> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
  </svg>
);

const ShieldIcon: React.FC<IconProps> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
);


const NavItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick: () => void; }> = ({ icon, label, active, onClick }) => (
    <button
        onClick={onClick}
        className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 group ${
            active
                ? 'bg-dark-card-hover text-dark-text-primary shadow-inner'
                : 'text-dark-text-secondary hover:bg-dark-card-hover hover:text-dark-text-primary'
        }`}
    >
        <span className={active ? 'text-brand-secondary' : 'text-dark-text-secondary group-hover:text-dark-text-primary'}>{icon}</span>
        <span className="ml-3">{label}</span>
    </button>
);

interface SidebarProps {
    activeView: string;
    setActiveView: (view: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView }) => {
    return (
        <aside className="hidden md:flex flex-col w-64 bg-dark-card border-r border-dark-border">
            <div className="flex items-center justify-center h-16 border-b border-dark-border">
                <ShieldIcon className="w-8 h-8 text-brand-primary" />
                <span className="ml-2 text-xl font-bold bg-gradient-to-r from-brand-primary to-brand-secondary text-transparent bg-clip-text">SilaKelima</span>
            </div>
            <div className="flex-1 p-4 space-y-2 overflow-y-auto">
                <nav>
                    <NavItem icon={<HomeIcon className="w-6 h-6" />} label="Dashboard" active={activeView === 'dashboard'} onClick={() => setActiveView('dashboard')} />
                    <NavItem icon={<TransactionIcon className="w-6 h-6" />} label="Transaksi" active={activeView === 'transactions'} onClick={() => setActiveView('transactions')} />
                    <NavItem icon={<ChartIcon className="w-6 h-6" />} label="Analitik Pajak" active={activeView === 'tax-analytics'} onClick={() => setActiveView('tax-analytics')} />
                    <NavItem icon={<AIIcon className="w-6 h-6" />} label="Asisten AI" active={activeView === 'ai-assistant'} onClick={() => setActiveView('ai-assistant')} />
                </nav>
            </div>
             <div className="p-4 border-t border-dark-border">
                <p className="text-xs text-center text-dark-text-secondary">
                    BI-OJK Hackathon 2025
                    <br />
                    Financial Innovation & Public Services
                </p>
            </div>
        </aside>
    );
};

export default Sidebar;