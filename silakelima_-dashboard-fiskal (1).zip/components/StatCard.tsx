import React from 'react';
import type { Stat } from '../types';

const StatCard: React.FC<Stat> = ({ title, value, change, changeType, icon }) => {
    const changeColor = changeType === 'increase' ? 'text-green-400' : 'text-red-400';
    
    return (
        <div className="group bg-dark-card border border-dark-border p-5 rounded-xl flex items-center space-x-4 hover:bg-dark-card-hover hover:-translate-y-1 hover:shadow-2xl hover:shadow-brand-primary/10 transition-all duration-300 ease-in-out">
            <div className="p-3 bg-gradient-to-br from-brand-primary to-brand-accent rounded-lg shadow-lg">
                {icon}
            </div>
            <div>
                <p className="text-sm text-dark-text-secondary font-medium">{title}</p>
                <p className="text-2xl font-bold text-dark-text-primary">{value}</p>
                {change && (
                    <p className={`text-xs font-semibold ${changeColor}`}>{change}</p>
                )}
            </div>
        </div>
    );
};

export default StatCard;