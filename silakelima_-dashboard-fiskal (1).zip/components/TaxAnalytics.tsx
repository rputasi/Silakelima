import React, { useState, useMemo, useCallback } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import StatCard from './StatCard';
import { MOCK_TRANSACTIONS } from '../constants';
import type { Stat, Transaction, Industry } from '../types';
import { classifyTransactionDetails } from '../services/geminiService';

const ScaleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l-6-2m6 2l3 1m-3-1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2" />
  </svg>
);

const DocumentReportIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);

const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
    </svg>
);

const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
};

interface CustomTooltipProps {
    active?: boolean;
    payload?: any[];
    label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="p-3 bg-dark-card-hover/90 backdrop-blur-sm border border-dark-border rounded-lg shadow-lg">
                <p className="label text-md font-bold text-dark-text-primary">{label}</p>
                {payload.map((pld, index) => (
                    <p key={index} style={{ color: pld.fill }} className="intro text-sm font-medium">
                        {`${pld.name}: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(pld.value)}`}
                    </p>
                ))}
            </div>
        );
    }
    return null;
};


const TaxAnalytics: React.FC = () => {
    const [transactions] = useState(MOCK_TRANSACTIONS);
    const [purpose, setPurpose] = useState('');
    const [classificationResult, setClassificationResult] = useState<{ category: string, industry: string } | null>(null);
    const [isClassifying, setIsClassifying] = useState(false);
    
    const highTaxTransactions = useMemo(() => {
        return transactions
            .filter(t => t.pajakAPT > 100000)
            .sort((a,b) => b.pajakAPT - a.pajakAPT);
    }, [transactions]);

    const taxByCategory = useMemo(() => {
        const data = transactions.reduce((acc, t) => {
            const cat = t.kategori;
            if (!acc[cat]) { acc[cat] = 0; }
            acc[cat] += t.pajakAPT;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(data).map(([name, value]) => ({ name, value }));
    }, [transactions]);

    const taxByIndustry = useMemo(() => {
        const data = transactions.reduce((acc, t) => {
            if (t.industri) {
                const industry = t.industri;
                if (!acc[industry]) { acc[industry] = 0; }
                acc[industry] += t.pajakAPT;
            }
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(data).map(([name, value]) => ({ name, 'Pajak APT': value })).sort((a,b) => b['Pajak APT'] - a['Pajak APT']);
    }, [transactions]);


    const stats: Stat[] = useMemo(() => {
        const totalTax = transactions.reduce((acc, t) => acc + t.pajakAPT, 0);
        const topCategory = taxByCategory.sort((a,b) => b.value - a.value)[0];
        return [
            { title: 'Total Pajak APT Terkumpul', value: formatCurrency(totalTax), icon: <DocumentReportIcon className="w-8 h-8 text-white" /> },
            { title: 'Kategori Pajak Terbesar', value: topCategory.name, change: formatCurrency(topCategory.value), icon: <ScaleIcon className="w-8 h-8 text-white" /> },
            { title: 'Transaksi Pajak Tinggi', value: `${highTaxTransactions.length} Transaksi`, change: '> Rp 100.000 Pajak', icon: <SparklesIcon className="w-8 h-8 text-white" /> },
        ];
    }, [transactions, taxByCategory, highTaxTransactions]);

    const handleClassification = useCallback(async () => {
        if (!purpose.trim()) return;
        setIsClassifying(true);
        setClassificationResult(null);
        try {
            const result = await classifyTransactionDetails(purpose);
            setClassificationResult(result);
        } catch (error) {
            console.error(error);
            setClassificationResult({ category: 'Gagal', industry: 'Gagal melakukan klasifikasi.' });
        } finally {
            setIsClassifying(false);
        }
    }, [purpose]);

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-dark-text-primary">Analitik Pajak & Klasifikasi Industri</h2>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {stats.map((stat, index) => <StatCard key={index} {...stat} />)}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-dark-card border border-dark-border rounded-xl p-6 shadow-lg">
                    <h3 className="text-xl font-semibold text-dark-text-primary mb-4">Distribusi Pajak per Industri</h3>
                    <ResponsiveContainer width="100%" height={350}>
                         <BarChart data={taxByIndustry} layout="vertical" margin={{ top: 5, right: 20, left: 40, bottom: 5 }}>
                             <defs>
                                <linearGradient id="colorTaxBar" x1="0" y1="0" x2="1" y2="0">
                                    <stop offset="0%" stopColor="#8b5cf6" stopOpacity={1}/>
                                    <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.8}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke={'#334155'} />
                            <XAxis type="number" stroke={'#94a3b8'} tickFormatter={(value) => new Intl.NumberFormat('id-ID', { notation: 'compact', compactDisplay: 'short' }).format(value as number)} />
                            <YAxis type="category" dataKey="name" stroke={'#94a3b8'} width={100} tick={{fontSize: 12}} />
                            <Tooltip
                                content={<CustomTooltip />}
                                cursor={{ fill: 'rgba(51, 65, 85, 0.5)' }}
                            />
                            <Bar dataKey="Pajak APT" fill="url(#colorTaxBar)" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
                 <div className="relative bg-dark-card border border-dark-border rounded-xl p-6 flex flex-col shadow-lg">
                    <div className="absolute -inset-0.5 bg-gradient-to-r from-brand-accent to-brand-secondary rounded-xl opacity-0 group-hover:opacity-75 transition duration-500 blur"></div>
                    <div className="relative z-10 flex flex-col h-full">
                        <h3 className="text-xl font-semibold text-dark-text-primary mb-4">Klasifikasi Transaksi AI</h3>
                        <p className="text-sm text-dark-text-secondary mb-4">Masukkan tujuan transaksi untuk diklasifikasikan oleh AI.</p>
                        <textarea
                            value={purpose}
                            onChange={(e) => setPurpose(e.target.value)}
                            placeholder="Contoh: Pembelian software untuk kantor"
                            className="flex-grow w-full p-2 text-dark-text-primary bg-dark-bg border border-dark-border rounded-md focus:outline-none focus:ring-1 focus:ring-brand-primary"
                            rows={3}
                            disabled={isClassifying}
                        />
                        <button
                            onClick={handleClassification}
                            className="mt-4 w-full px-4 py-2 font-semibold text-white bg-brand-primary rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-card focus:ring-brand-primary disabled:opacity-50"
                            disabled={isClassifying || !purpose.trim()}
                        >
                            {isClassifying ? 'Menganalisis...' : 'Lakukan Klasifikasi AI'}
                        </button>
                        {classificationResult && (
                            <div className="mt-4 text-center bg-dark-bg/50 p-4 rounded-lg space-y-2 border border-dark-border">
                                <div>
                                    <p className="text-sm text-dark-text-secondary">Kategori:</p>
                                    <p className="text-lg font-bold text-brand-secondary">{classificationResult.category}</p>
                                </div>
                                <div className='pt-2 border-t border-dark-border'>
                                    <p className="text-sm text-dark-text-secondary">Industri:</p>
                                    <p className="text-lg font-bold text-brand-secondary">{classificationResult.industry}</p>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>

             <div className="bg-dark-card border border-dark-border rounded-xl shadow-lg">
                 <h3 className="text-xl font-semibold p-4">Monitoring Transaksi Pajak Tinggi</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full text-sm text-left text-dark-text-secondary">
                        <thead className="text-xs uppercase bg-dark-bg/50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Tujuan Transaksi</th>
                                <th scope="col" className="px-6 py-3">Industri</th>
                                <th scope="col" className="px-6 py-3 text-right">Nominal</th>
                                <th scope="col" className="px-6 py-3 text-right">Pajak APT</th>
                            </tr>
                        </thead>
                        <tbody>
                            {highTaxTransactions.map((t) => (
                                <tr key={t.kodeUnik} className="border-b border-dark-border hover:bg-dark-card-hover even:bg-dark-bg/30">
                                    <td className="px-6 py-4 font-medium text-dark-text-primary">{t.tujuanTransaksi}</td>
                                    <td className="px-6 py-4">
                                        {t.industri ? (
                                             <span className="px-2 py-1 text-xs font-medium rounded-full bg-purple-900/70 text-purple-300">
                                                {t.industri}
                                             </span>
                                        ) : (
                                            <span className="text-xs text-dark-text-secondary italic">N/A</span>
                                        )}
                                    </td>
                                    <td className="px-6 py-4 text-right font-medium">{formatCurrency(t.nominalTransaksi)}</td>
                                    <td className="px-6 py-4 text-right font-bold text-yellow-400">{formatCurrency(t.pajakAPT)}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default TaxAnalytics;