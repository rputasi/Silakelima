import React, { useState, useEffect, useMemo } from 'react';
import { getAIInsights } from '../services/geminiService';
import type { Transaction, Insight } from '../types';

const LightbulbIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
  </svg>
);

const TrendingUpIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
  </svg>
);

const WarningIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
  </svg>
);

const Shimmer: React.FC = () => (
    <div className="flex items-start space-x-4 p-4 bg-dark-bg/50 rounded-lg border border-dark-border">
        <div className="w-10 h-10 rounded-full bg-slate-700"></div>
        <div className="flex-1 space-y-3 py-1">
            <div className="h-4 bg-slate-700 rounded w-3/4"></div>
            <div className="h-4 bg-slate-700 rounded w-5/6"></div>
        </div>
    </div>
);


const InsightCard: React.FC<{ insight: Insight }> = ({ insight }) => {
    const { icon, color } = useMemo(() => {
        switch (insight.type) {
            case 'anomaly':
                return { icon: <WarningIcon className="w-5 h-5" />, color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' };
            case 'trend':
                return { icon: <TrendingUpIcon className="w-5 h-5" />, color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' };
            case 'observation':
            default:
                return { icon: <LightbulbIcon className="w-5 h-5" />, color: 'bg-teal-500/20 text-teal-400 border-teal-500/30' };
        }
    }, [insight.type]);

    return (
        <div className="flex items-start space-x-4 p-4 bg-dark-bg/50 rounded-lg border border-dark-border">
            <div className={`p-2 rounded-full ${color}`}>
                {icon}
            </div>
            <div>
                <h4 className="font-bold text-dark-text-primary">{insight.title}</h4>
                <p className="text-sm text-dark-text-secondary">{insight.description}</p>
            </div>
        </div>
    );
}

const AIInsights: React.FC<{ transactions: Transaction[] }> = ({ transactions }) => {
    const [insights, setInsights] = useState<Insight[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchInsights = async () => {
            setIsLoading(true);
            setError('');
            try {
                // Add a small delay to make shimmer visible
                await new Promise(resolve => setTimeout(resolve, 500)); 
                const results = await getAIInsights(transactions);
                setInsights(results);
            } catch (err) {
                console.error(err);
                setError('Gagal memuat wawasan dari AI.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchInsights();
    }, [transactions]);

    const renderContent = () => {
        if (isLoading) {
            return (
                <div className="overflow-hidden relative space-y-4">
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-slate-700/50 to-transparent -translate-x-full animate-[shimmer_1.5s_infinite]"></div>
                    <Shimmer />
                    <Shimmer />
                    <Shimmer />
                </div>
            );
        }

        if (error) {
            return (
                 <div className="flex items-start space-x-4 p-4 bg-red-900/20 rounded-lg border border-red-500/50">
                    <div className="p-2 rounded-full text-white bg-red-500">
                        <WarningIcon className="w-5 h-5" />
                    </div>
                    <div>
                        <h4 className="font-bold text-red-400">Terjadi Kesalahan</h4>
                        <p className="text-sm text-dark-text-secondary">{error}</p>
                    </div>
                </div>
            );
        }

        return insights.map((insight, index) => <InsightCard key={index} insight={insight} />);
    };


    return (
        <div className="bg-dark-card border border-dark-border rounded-xl p-4 md:p-6 shadow-lg">
            <h3 className="text-xl font-semibold text-dark-text-primary mb-4">Wawasan Otomatis AI</h3>
            <div className="space-y-4">
                {renderContent()}
            </div>
        </div>
    );
};

export default AIInsights;