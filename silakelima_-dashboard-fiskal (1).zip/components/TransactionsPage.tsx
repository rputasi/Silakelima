import React, { useState, useMemo } from 'react';
import { MOCK_TRANSACTIONS } from '../constants';
import { Transaction } from '../types';

const TransactionsPage: React.FC = () => {
    const [transactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterCategory, setFilterCategory] = useState('all');
    const transactionsPerPage = 10;

    const categories = useMemo(() => ['all', ...Array.from(new Set(transactions.map(t => t.kategori)))], [transactions]);

    const filteredTransactions = useMemo(() => {
        return transactions
            .filter(t => {
                if (!searchTerm) return true;
                const term = searchTerm.toLowerCase();
                return (
                    t.kodeUnik.toLowerCase().includes(term) ||
                    t.tujuanTransaksi.toLowerCase().includes(term) ||
                    t.penyediaJasaPengirim.toLowerCase().includes(term) ||
                    t.penyediaJasaPenerima.toLowerCase().includes(term) ||
                    t.nikPengirim.includes(term) ||
                    t.nikPenerima.includes(term)
                );
            })
            .filter(t => {
                return filterCategory === 'all' || t.kategori === filterCategory;
            });
    }, [transactions, searchTerm, filterCategory]);

    const totalPages = Math.ceil(filteredTransactions.length / transactionsPerPage);
    const paginatedTransactions = useMemo(() => {
        const indexOfLastTransaction = currentPage * transactionsPerPage;
        const indexOfFirstTransaction = indexOfLastTransaction - transactionsPerPage;
        return filteredTransactions.slice(indexOfFirstTransaction, indexOfLastTransaction);
    }, [filteredTransactions, currentPage, transactionsPerPage]);


    const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
    };
    
    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('id-ID', {
            year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    };

    return (
        <div className="space-y-6">
            <h2 className="text-3xl font-bold text-dark-text-primary">Daftar Lengkap Transaksi</h2>
            
            <div className="bg-dark-card border border-dark-border rounded-xl p-4 shadow-lg">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="w-full md:w-1/2 lg:w-2/3">
                        <input
                            type="text"
                            placeholder="Cari berdasarkan kode, tujuan, NIK, penyedia jasa..."
                            className="w-full py-2 px-4 text-dark-text-primary bg-dark-bg border border-dark-border rounded-md focus:outline-none focus:ring-1 focus:ring-brand-primary"
                            onChange={(e) => {
                                setSearchTerm(e.target.value);
                                setCurrentPage(1);
                            }}
                        />
                    </div>
                    <div className="w-full md:w-auto">
                        <select
                            className="w-full py-2 px-4 text-dark-text-primary bg-dark-bg border border-dark-border rounded-md focus:outline-none focus:ring-1 focus:ring-brand-primary"
                            onChange={(e) => {
                                setFilterCategory(e.target.value);
                                setCurrentPage(1);
                            }}
                            value={filterCategory}
                        >
                            {categories.map(cat => (
                                <option key={cat} value={cat}>{cat === 'all' ? 'Semua Kategori' : cat}</option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>

            <div className="bg-dark-card border border-dark-border rounded-xl shadow-lg">
                 <div className="overflow-x-auto">
                    <table className="min-w-full text-sm text-left text-dark-text-secondary">
                        <thead className="text-xs uppercase bg-dark-bg/50">
                            <tr>
                                <th scope="col" className="px-6 py-3">Detail Transaksi</th>
                                <th scope="col" className="px-6 py-3">Pengirim</th>
                                <th scope="col" className="px-6 py-3">Penerima</th>
                                <th scope="col" className="px-6 py-3">Kategori</th>
                                <th scope="col" className="px-6 py-3 text-right">Nominal & Pajak</th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginatedTransactions.map((t) => (
                                <tr key={t.kodeUnik} className="border-b border-dark-border hover:bg-dark-card-hover even:bg-dark-bg/30">
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-dark-text-primary">{t.tujuanTransaksi}</div>
                                        <div className="font-mono text-xs">{t.kodeUnik}</div>
                                        <div className="text-xs text-dark-text-secondary">{formatDate(t.tanggalJam)}</div>
                                    </td>
                                     <td className="px-6 py-4">
                                        <div className="font-medium text-dark-text-primary">{t.penyediaJasaPengirim}</div>
                                        <div className="text-xs text-dark-text-secondary">NIK: {t.nikPengirim}</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="font-medium text-dark-text-primary">{t.penyediaJasaPenerima}</div>
                                        <div className="text-xs text-dark-text-secondary">NIK: {t.nikPenerima}</div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                            t.kategori === 'Bisnis' ? 'bg-blue-900/70 text-blue-300' :
                                            t.kategori === 'Gaji' ? 'bg-indigo-900/70 text-indigo-300' :
                                            t.kategori === 'Belanja Ritel' ? 'bg-pink-900/70 text-pink-300' :
                                            t.kategori === 'Investasi' ? 'bg-amber-900/70 text-amber-300' :
                                            'bg-slate-700/70 text-slate-300'
                                        }`}>
                                            {t.kategori}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <div className="font-medium text-dark-text-primary">{formatCurrency(t.nominalTransaksi)}</div>
                                        <div className="font-medium text-green-400">{formatCurrency(t.pajakAPT)}</div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                     {filteredTransactions.length === 0 && (
                        <div className="text-center p-8 text-dark-text-secondary">
                            <p className="font-semibold">Tidak ada transaksi ditemukan</p>
                            <p className="text-sm">Coba sesuaikan filter atau kata kunci pencarian Anda.</p>
                        </div>
                    )}
                    <div className="flex justify-between items-center p-4">
                        <span className="text-sm text-dark-text-secondary">
                            Menampilkan {Math.min(paginatedTransactions.length > 0 ? (currentPage - 1) * transactionsPerPage + 1 : 0, filteredTransactions.length)}-{Math.min(currentPage * transactionsPerPage, filteredTransactions.length)} dari {filteredTransactions.length} transaksi
                        </span>
                        <div className="inline-flex rounded-md shadow-sm" role="group">
                            <button onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} className="px-3 py-2 text-sm font-medium text-dark-text-secondary bg-dark-card border border-dark-border rounded-l-lg hover:bg-dark-card-hover hover:text-dark-text-primary disabled:opacity-50 disabled:cursor-not-allowed">
                                Sebelumnya
                            </button>
                            <button onClick={() => paginate(currentPage + 1)} disabled={currentPage === totalPages || totalPages === 0} className="px-3 py-2 text-sm font-medium  text-dark-text-secondary bg-dark-card border-t border-b border-r border-dark-border rounded-r-lg hover:bg-dark-card-hover hover:text-dark-text-primary disabled:opacity-50 disabled:cursor-not-allowed">
                                Berikutnya
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TransactionsPage;