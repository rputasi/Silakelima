import React, { useState } from 'react';
import { Transaction } from '../types';

interface TransactionsTableProps {
  transactions: Transaction[];
}

const TransactionsTable: React.FC<TransactionsTableProps> = ({ transactions }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const transactionsPerPage = 5;

    const indexOfLastTransaction = currentPage * transactionsPerPage;
    const indexOfFirstTransaction = indexOfLastTransaction - transactionsPerPage;
    const currentTransactions = transactions.slice(indexOfFirstTransaction, indexOfLastTransaction);

    const totalPages = Math.ceil(transactions.length / transactionsPerPage);

    const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
    };
    
    const formatDate = (dateString: string) => {
        return new Date(dateString).toLocaleDateString('id-ID', {
            year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    };

    return (
        <div className="overflow-x-auto">
            <div className="p-4">
                <h3 className="text-xl font-semibold">Transaksi Terbaru</h3>
            </div>
            <table className="min-w-full text-sm text-left text-dark-text-secondary">
                <thead className="text-xs uppercase bg-dark-bg/50">
                    <tr>
                        <th scope="col" className="px-6 py-3">Kode Unik</th>
                        <th scope="col" className="px-6 py-3">Tanggal</th>
                        <th scope="col" className="px-6 py-3">Kanal</th>
                        <th scope="col" className="px-6 py-3">Pengirim</th>
                        <th scope="col" className="px-6 py-3">Penerima</th>
                        <th scope="col" className="px-6 py-3 text-right">Nominal</th>
                        <th scope="col" className="px-6 py-3 text-right">Pajak APT</th>
                    </tr>
                </thead>
                <tbody>
                    {currentTransactions.map((t) => (
                        <tr key={t.kodeUnik} className="border-b border-dark-border hover:bg-dark-card-hover even:bg-dark-bg/30">
                            <td className="px-6 py-4 font-mono text-xs">{t.kodeUnik}</td>
                            <td className="px-6 py-4">{formatDate(t.tanggalJam)}</td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                    t.kanalTransaksi === 'RTGS' ? 'bg-blue-900/70 text-blue-300' :
                                    t.kanalTransaksi === 'ATM' ? 'bg-green-900/70 text-green-300' :
                                    t.kanalTransaksi === 'Kartu Kredit' ? 'bg-yellow-900/70 text-yellow-300' :
                                    'bg-slate-700/70 text-slate-300'
                                }`}>
                                    {t.kanalTransaksi}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <div className="font-medium text-dark-text-primary">{t.penyediaJasaPengirim}</div>
                                <div className="text-xs text-dark-text-secondary">{t.nikPengirim}</div>
                            </td>
                            <td className="px-6 py-4">
                                <div className="font-medium text-dark-text-primary">{t.penyediaJasaPenerima}</div>
                                <div className="text-xs text-dark-text-secondary">{t.nikPenerima}</div>
                            </td>
                            <td className="px-6 py-4 text-right font-medium text-dark-text-primary">{formatCurrency(t.nominalTransaksi)}</td>
                            <td className="px-6 py-4 text-right font-medium text-green-400">{formatCurrency(t.pajakAPT)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
            <div className="flex justify-between items-center p-4">
                <span className="text-sm text-dark-text-secondary">
                    Menampilkan {indexOfFirstTransaction + 1}-{Math.min(indexOfLastTransaction, transactions.length)} dari {transactions.length} transaksi
                </span>
                <div className="inline-flex rounded-md shadow-sm" role="group">
                    <button onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1} className="px-3 py-2 text-sm font-medium text-dark-text-secondary bg-dark-card border border-dark-border rounded-l-lg hover:bg-dark-card-hover hover:text-dark-text-primary disabled:opacity-50 disabled:cursor-not-allowed">
                        Sebelumnya
                    </button>
                    <button onClick={() => paginate(currentPage + 1)} disabled={currentPage === totalPages} className="px-3 py-2 text-sm font-medium  text-dark-text-secondary bg-dark-card border-t border-b border-r border-dark-border rounded-r-lg hover:bg-dark-card-hover hover:text-dark-text-primary disabled:opacity-50 disabled:cursor-not-allowed">
                        Berikutnya
                    </button>
                </div>
            </div>
        </div>
    );
};

export default TransactionsTable;