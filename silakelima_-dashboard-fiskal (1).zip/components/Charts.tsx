import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Transaction } from '../types';

interface CustomTooltipProps {
    active?: boolean;
    payload?: any[];
    label?: string;
}

const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="p-3 bg-dark-card-hover/90 backdrop-blur-sm border border-dark-border rounded-lg shadow-lg">
                <p className="label text-md font-bold text-dark-text-primary">{label}</p>
                {payload.map((pld, index) => (
                    <p key={index} style={{ color: pld.color }} className="intro text-sm font-medium">
                        {`${pld.name}: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(pld.value)}`}
                    </p>
                ))}
            </div>
        );
    }
    return null;
};


const Charts: React.FC<{ transactions: Transaction[] }> = ({ transactions }) => {

    const volumeByCategory = useMemo(() => {
        const data = transactions.reduce((acc, t) => {
            const category = t.kategori;
            if (!acc[category]) {
                acc[category] = 0;
            }
            acc[category] += t.nominalTransaksi;
            return acc;
        }, {} as Record<string, number>);

        return Object.entries(data).map(([name, value]) => ({ name, 'Volume Transaksi': value })).sort((a,b) => b['Volume Transaksi'] - a['Volume Transaksi']);
    }, [transactions]);

    const taxByChannel = useMemo(() => {
        const data = transactions.reduce((acc, t) => {
            const channel = t.kanalTransaksi;
            if (!acc[channel]) {
                acc[channel] = 0;
            }
            acc[channel] += t.pajakAPT;
            return acc;
        }, {} as Record<string, number>);

        return Object.entries(data).map(([name, value]) => ({ name, 'Pajak APT': value })).sort((a,b) => b['Pajak APT'] - a['Pajak APT']);
    }, [transactions]);
    
    const transactionsOverTime = useMemo(() => {
        const sorted = [...transactions].sort((a, b) => new Date(a.tanggalJam).getTime() - new Date(b.tanggalJam).getTime());
        return sorted.map(t => ({
            date: new Date(t.tanggalJam).toLocaleDateString('id-ID', { month: 'short', day: 'numeric' }),
            Nominal: t.nominalTransaksi,
            Pajak: t.pajakAPT
        }));
    }, [transactions]);

    return (
        <div className="space-y-8 h-full flex flex-col">
            <h3 className="text-xl font-semibold text-dark-text-primary">Analitik Transaksi</h3>
            <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-8">
                 <div>
                    <h4 className="text-md font-medium text-dark-text-secondary mb-4">Volume Transaksi per Kategori</h4>
                    <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={volumeByCategory} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                             <defs>
                                <linearGradient id="colorBarPrimary" x1="0" y1="0" x2="1" y2="0">
                                    <stop offset="0%" stopColor="#3b82f6" stopOpacity={1}/>
                                    <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke={'#334155'} />
                            <XAxis type="number" stroke={'#94a3b8'} tickFormatter={(value) => new Intl.NumberFormat('id-ID', { notation: 'compact', compactDisplay: 'short' }).format(value as number)} />
                            <YAxis type="category" dataKey="name" stroke={'#94a3b8'} width={80} tick={{fontSize: 12}} />
                            <Tooltip
                                cursor={{ fill: 'rgba(51, 65, 85, 0.5)' }}
                                content={<CustomTooltip />}
                            />
                            <Bar dataKey="Volume Transaksi" fill="url(#colorBarPrimary)" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
                 <div>
                    <h4 className="text-md font-medium text-dark-text-secondary mb-4">Pajak APT Terkumpul per Kanal</h4>
                    <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={taxByChannel} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                            <defs>
                                <linearGradient id="colorBarSecondary" x1="0" y1="0" x2="1" y2="0">
                                    <stop offset="0%" stopColor="#14b8a6" stopOpacity={1}/>
                                    <stop offset="100%" stopColor="#22d3ee" stopOpacity={0.8}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke={'#334155'} />
                            <XAxis type="number" stroke={'#94a3b8'} tickFormatter={(value) => new Intl.NumberFormat('id-ID', { notation: 'compact', compactDisplay: 'short' }).format(value as number)} />
                            <YAxis type="category" dataKey="name" stroke={'#94a3b8'} width={80} tick={{fontSize: 12}}/>
                            <Tooltip
                                cursor={{ fill: 'rgba(51, 65, 85, 0.5)' }}
                                content={<CustomTooltip />}
                            />
                            <Bar dataKey="Pajak APT" fill="url(#colorBarSecondary)" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
             <div className="flex-grow mt-8">
                 <h4 className="text-md font-medium text-dark-text-secondary mb-4">Tren Transaksi & Pajak</h4>
                 <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={transactionsOverTime} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                        <defs>
                            <linearGradient id="colorAreaPrimary" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke={'#334155'}/>
                        <XAxis dataKey="date" stroke={'#94a3b8'} tick={{fontSize: 12}} />
                        <YAxis stroke={'#94a3b8'} tickFormatter={(value) => new Intl.NumberFormat('id-ID', { notation: 'compact', compactDisplay: 'short' }).format(value as number)} tick={{fontSize: 12}} />
                         <Tooltip
                            cursor={{ fill: 'rgba(51, 65, 85, 0.5)' }}
                            content={<CustomTooltip />}
                        />
                        <Area type="monotone" dataKey="Nominal" stroke={'#3b82f6'} fillOpacity={1} fill="url(#colorAreaPrimary)" />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default Charts;