import { Transaction, Industry } from './types';

// =================================================================
// Data Generation Engine
// =================================================================

/**
 * Gets a random item from an array.
 * @param arr The array to pick from.
 * @returns A random item from the array.
 */
const getRandomItem = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

/**
 * Generates a random number within a specified range.
 * @param min The minimum value.
 * @param max The maximum value.
 * @returns A random integer.
 */
const getRandomNumber = (min: number, max: number): number => Math.floor(Math.random() * (max - min + 1)) + min;

/**
 * Generates a random BigInt for NIK simulation, avoiding floating point limitations.
 * @param min The minimum BigInt value.
 * @param max The maximum BigInt value.
 * @returns A random BigInt.
 */
const getRandomBigInt = (min: bigint, max: bigint): bigint => {
    const range = max - min;
    const bits = range.toString(2).length;
    let random;
    do {
        random = BigInt(0);
        for (let i = 0; i < bits; i++) {
            random = (random << BigInt(1)) | BigInt(Math.round(Math.random()));
        }
    } while (random > range);
    return min + random;
};

/**
 * Generates random geographic coordinates within Indonesia's approximate bounds.
 * @returns A location string in "latitude, longitude" format.
 */
const getRandomLocation = (): string => {
    const lat = Math.random() * (6 - (-11)) + (-11);
    const lon = Math.random() * (141 - 95) + 95;
    return `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
};

/**
 * Generates a specified number of mock transactions.
 * @param count The number of transactions to generate.
 * @returns An array of Transaction objects.
 */
const generateTransactions = (count: number): Transaction[] => {
    const transactions: Transaction[] = [];
    const providers = ['BCA', 'Mandiri', 'BRI', 'BNI', 'CIMB Niaga', 'GoPay', 'OVO', 'DANA', 'ShopeePay', 'LinkAja', 'BTN', 'Bank Jago', 'SeaBank', 'PermataBank', 'HSBC', 'UOB', 'DBS'];
    const channels = ['ATM', 'RTGS', 'Mobile Banking', 'Internet Banking', 'Kartu Kredit', 'Kartu Debit', 'Proprietary Channel'];
    const categories: Transaction['kategori'][] = ['Gaji', 'Belanja Ritel', 'Pembayaran Tagihan', 'Transfer', 'Investasi', 'Bisnis', 'Lainnya'];
    const industries: Industry[] = ['Keuangan & Asuransi', 'Teknologi & Informasi', 'Perdagangan & Eceran', 'Konstruksi', 'Manufaktur', 'Jasa Profesional', 'Pertambangan', 'Transportasi'];
    const purposeTemplates: Record<Transaction['kategori'], string[]> = {
        'Gaji': ['Pembayaran Gaji', 'Gaji Karyawan', 'Upah Proyek', 'Bonus Tahunan'],
        'Belanja Ritel': ['Belanja Bulanan di Supermarket', 'Pembelian Online Marketplace', 'Makan di Restoran', 'Beli Kopi Kekinian', 'Pembelian Gadget Baru', 'Bayar Parkir', 'Tiket Bioskop'],
        'Pembayaran Tagihan': ['Bayar Listrik PLN', 'Tagihan Internet IndiHome', 'Premi Asuransi Jiwa', 'Bayar UKT Universitas', 'Cicilan Kendaraan', 'Tagihan Kartu Kredit', 'Bayar PDAM'],
        'Transfer': ['Transfer ke Keluarga', 'Kirim Uang ke Teman', 'Top-up e-wallet OVO', 'Top-up GoPay', 'Isi Saldo DANA'],
        'Investasi': ['Pembelian Saham BBCA', 'Top Up RDN Ajaib', 'Beli Obligasi Pemerintah SBR013', 'Investasi Reksadana Pasar Uang', 'Pembelian Properti'],
        'Bisnis': ['Pembayaran Vendor IT', 'Modal Usaha Startup', 'Pembelian Material Konstruksi', 'Supply Chain Financing', 'Jasa Konsultasi Pajak', 'Pengadaan Barang Kantor', 'Biaya Logistik Ekspor'],
        'Lainnya': ['Tarik Tunai ATM', 'Donasi Yayasan Anak', 'Uang Kaget Giveaway', 'Biaya Administrasi']
    };

    const nikMin = 1101010000000000n;
    const nikMax = 9471010000000000n;

    for (let i = 0; i < count; i++) {
        const kategori = getRandomItem(categories);
        const kanal = getRandomItem(channels);
        
        let nominalTransaksi;
        if (kanal === 'RTGS' || kategori === 'Bisnis' || kategori === 'Investasi') {
            nominalTransaksi = getRandomNumber(50_000_000, 2_000_000_000);
        } else if (kategori === 'Gaji') {
            nominalTransaksi = getRandomNumber(3_000_000, 25_000_000);
        } else {
            nominalTransaksi = getRandomNumber(10_000, 5_000_000);
        }
        
        const pajakAPT = Math.round(nominalTransaksi * 0.001);
        const hasIndustry = ['Bisnis', 'Investasi', 'Gaji', 'Pembayaran Tagihan'].includes(kategori);
        
        const transaction: Transaction = {
            kodeUnik: Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10),
            tanggalJam: new Date(Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)).toISOString(),
            kanalTransaksi: kanal,
            nomorRekeningPengirim: String(getRandomNumber(1000000000, 9999999999)),
            nikPengirim: getRandomBigInt(nikMin, nikMax).toString(),
            penyediaJasaPengirim: getRandomItem(providers),
            lokasiPengirim: getRandomLocation(),
            nominalTransaksi: nominalTransaksi,
            pajakAPT: pajakAPT,
            nikPenerima: getRandomBigInt(nikMin, nikMax).toString(),
            nomorRekeningPenerima: String(getRandomNumber(1000000000, 9999999999)),
            penyediaJasaPenerima: getRandomItem(providers),
            tujuanTransaksi: getRandomItem(purposeTemplates[kategori]),
            kategori: kategori,
        };
        
        if (hasIndustry) {
            if (kategori === 'Investasi' || (kategori === 'Pembayaran Tagihan' && Math.random() > 0.5)) {
                 transaction.industri = 'Keuangan & Asuransi';
            } else if (kategori !== 'Lainnya') {
                 transaction.industri = getRandomItem(industries);
            }
        }

        transactions.push(transaction);
    }
    return transactions;
}


// =================================================================
// Original Dataset
// =================================================================

const originalTransactions: Transaction[] = [
  {
    "kodeUnik": "Opmym5aadxav851k",
    "tanggalJam": "2025-07-04T04:35:58Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "9581807133",
    "nikPengirim": "1202034802929040",
    "penyediaJasaPengirim": "OVO",
    "lokasiPengirim": "0.518506, 140.864965",
    "nominalTransaksi": 150000,
    "pajakAPT": 150,
    "nikPenerima": "1101011605837",
    "nomorRekeningPenerima": "9442100758",
    "penyediaJasaPenerima": "BNI",
    "tujuanTransaksi": "Pembelian",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "d43lwlntgdrhrdg2",
    "tanggalJam": "2025-07-30T01:46:29Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "5531955292",
    "nikPengirim": "3404022409007580",
    "penyediaJasaPengirim": "ShopeePay",
    "lokasiPengirim": "-6.940125, 136.447998",
    "nominalTransaksi": 1000000,
    "pajakAPT": 1000,
    "nikPenerima": "3202031707756",
    "nomorRekeningPenerima": "208688518",
    "penyediaJasaPenerima": "Mandiri",
    "tujuanTransaksi": "Pembayaran",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "ej5n4oluekxuphwu",
    "tanggalJam": "2025-07-12T15:36:39Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "9211362540",
    "nikPengirim": "1202031003871950",
    "penyediaJasaPengirim": "BNI",
    "lokasiPengirim": "-0.46606, 132.469022",
    "nominalTransaksi": 151743828,
    "pajakAPT": 151744,
    "nikPenerima": "3101015807998",
    "nomorRekeningPenerima": "6031890524",
    "penyediaJasaPenerima": "BRI",
    "tujuanTransaksi": "Transfer Bisnis",
    "kategori": "Bisnis",
    "industri": "Jasa Profesional"
  },
  {
    "kodeUnik": "q3u6brths42cjp3a",
    "tanggalJam": "2025-07-12T19:30:12Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "6986894800",
    "nikPengirim": "3202035402952290",
    "penyediaJasaPengirim": "Mandiri",
    "lokasiPengirim": "-7.192999, 98.361852",
    "nominalTransaksi": 305636839,
    "pajakAPT": 305637,
    "nikPenerima": "3306050000000",
    "nomorRekeningPenerima": "2734271511",
    "penyediaJasaPenerima": "BCA",
    "tujuanTransaksi": "Investasi Modal",
    "kategori": "Investasi",
    "industri": "Keuangan & Asuransi"
  },
  {
    "kodeUnik": "wwhp67i11rl1w7kv",
    "tanggalJam": "2025-07-17T00:31:07Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "523723621",
    "nikPengirim": "3404026408941080",
    "penyediaJasaPengirim": "ShopeePay",
    "lokasiPengirim": "-8.615383, 109.89842",
    "nominalTransaksi": 151685462,
    "pajakAPT": 151685,
    "nikPenerima": "1202036002777",
    "nomorRekeningPenerima": "7736025881",
    "penyediaJasaPenerima": "Mandiri",
    "tujuanTransaksi": "Supply Chain Financing",
    "kategori": "Bisnis",
    "industri": "Manufaktur"
  },
  {
    "kodeUnik": "hulggfrmqt4fvod2",
    "tanggalJam": "2025-07-28T19:06:25Z",
    "kanalTransaksi": "Kartu Kredit",
    "nomorRekeningPengirim": "887411292",
    "nikPengirim": "3306050508005310",
    "penyediaJasaPengirim": "Mandiri",
    "lokasiPengirim": "4.048429, 102.72138",
    "nominalTransaksi": 1000000,
    "pajakAPT": 1000,
    "nikPenerima": "3101020000000",
    "nomorRekeningPenerima": "7916946798",
    "penyediaJasaPenerima": "Merchant A",
    "tujuanTransaksi": "Pembayaran Tagihan",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "mckwx471k3uvumwk",
    "tanggalJam": "2025-07-30T20:50:09Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "4729542129",
    "nikPengirim": "3202031701786440",
    "penyediaJasaPengirim": "BTN",
    "lokasiPengirim": "-9.984623, 120.427676",
    "nominalTransaksi": 1000000,
    "pajakAPT": 1000,
    "nikPenerima": "1101012308012",
    "nomorRekeningPenerima": "3817807433",
    "penyediaJasaPenerima": "OVO",
    "tujuanTransaksi": "Top Up",
    "kategori": "Transfer"
  },
  {
    "kodeUnik": "i9ssxs3ucg9g4rkw",
    "tanggalJam": "2025-07-13T03:02:18Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "7349429184",
    "nikPengirim": "1202035411023560",
    "penyediaJasaPengirim": "LinkAja",
    "lokasiPengirim": "-4.069471, 104.336164",
    "nominalTransaksi": 244176136,
    "pajakAPT": 244176,
    "nikPenerima": "1101012504916",
    "nomorRekeningPenerima": "384819539",
    "penyediaJasaPenerima": "GoPay",
    "tujuanTransaksi": "Distribusi Dana Logistik",
    "kategori": "Bisnis",
    "industri": "Transportasi"
  },
  {
    "kodeUnik": "74gvl1f4ls86w8yw",
    "tanggalJam": "2025-07-26T06:20:13Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "1789631371",
    "nikPengirim": "3306055301847210",
    "penyediaJasaPengirim": "ShopeePay",
    "lokasiPengirim": "0.710935, 126.434387",
    "nominalTransaksi": 433432269,
    "pajakAPT": 433432,
    "nikPenerima": "1303042606824",
    "nomorRekeningPenerima": "5284790179",
    "penyediaJasaPenerima": "BRI",
    "tujuanTransaksi": "Pengadaan Barang Konstruksi",
    "kategori": "Bisnis",
    "industri": "Konstruksi"
  },
  {
    "kodeUnik": "klsyevsnna8q1dm4",
    "tanggalJam": "2025-07-09T22:45:44Z",
    "kanalTransaksi": "Kartu Kredit",
    "nomorRekeningPengirim": "7931666341",
    "nikPengirim": "1303042810016620",
    "penyediaJasaPengirim": "OVO",
    "lokasiPengirim": "-1.354601, 116.624916",
    "nominalTransaksi": 50000,
    "pajakAPT": 50,
    "nikPenerima": "3306050000000",
    "nomorRekeningPenerima": "4393189372",
    "penyediaJasaPenerima": "Merchant B",
    "tujuanTransaksi": "Pembelian Ritel",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "6a3xi33w4w0dmves",
    "tanggalJam": "2025-07-30T18:52:17Z",
    "kanalTransaksi": "Proprietary Channel",
    "nomorRekeningPengirim": "9743590852",
    "nikPengirim": "1202030603952700",
    "penyediaJasaPengirim": "BTN",
    "lokasiPengirim": "-4.590116, 104.96054",
    "nominalTransaksi": 5000000,
    "pajakAPT": 5000,
    "nikPenerima": "3101014106884",
    "nomorRekeningPenerima": "6994962726",
    "penyediaJasaPenerima": "BCA",
    "tujuanTransaksi": "Pembayaran Gaji",
    "kategori": "Gaji"
  },
  {
    "kodeUnik": "vy9di0sksl45wjss",
    "tanggalJam": "2025-07-28T09:44:57Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "3109312211",
    "nikPengirim": "3101026410762",
    "penyediaJasaPengirim": "BTN",
    "lokasiPengirim": "2.81232, 131.75174",
    "nominalTransaksi": 250000,
    "pajakAPT": 250,
    "nikPenerima": "1101014101736",
    "nomorRekeningPenerima": "7878644598",
    "penyediaJasaPenerima": "BRI",
    "tujuanTransaksi": "Pembayaran",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "2xjz9w5c5xwcsy0s",
    "tanggalJam": "2025-07-06T15:21:40Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "2816353928",
    "nikPengirim": "1101016801931080",
    "penyediaJasaPengirim": "GoPay",
    "lokasiPengirim": "-5.590103, 114.717904",
    "nominalTransaksi": 210085987,
    "pajakAPT": 210086,
    "nikPenerima": "3306050000000",
    "nomorRekeningPenerima": "8939678170",
    "penyediaJasaPenerima": "OVO",
    "tujuanTransaksi": "Pembayaran Proyek IT",
    "kategori": "Bisnis",
    "industri": "Teknologi & Informasi"
  },
  {
    "kodeUnik": "f90c8s9s2f8g8w4w",
    "tanggalJam": "2025-07-15T12:00:00Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "1234567890",
    "nikPengirim": "3101010101900001",
    "penyediaJasaPengirim": "BCA",
    "lokasiPengirim": "-6.200000, 106.816666",
    "nominalTransaksi": 7500000,
    "pajakAPT": 7500,
    "nikPenerima": "3101010202910002",
    "nomorRekeningPenerima": "0987654321",
    "penyediaJasaPenerima": "Mandiri",
    "tujuanTransaksi": "Pembayaran Gaji Karyawan",
    "kategori": "Gaji",
    "industri": "Teknologi & Informasi"
  },
  {
    "kodeUnik": "h2g4j6k8l3m1n5p7",
    "tanggalJam": "2025-07-16T09:30:15Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "1122334455",
    "nikPengirim": "3202030506800003",
    "penyediaJasaPengirim": "BRI",
    "lokasiPengirim": "-7.795580, 110.369492",
    "nominalTransaksi": 75000,
    "pajakAPT": 75,
    "nikPenerima": "3202030607810004",
    "nomorRekeningPenerima": "5566778899",
    "penyediaJasaPenerima": "GoPay",
    "tujuanTransaksi": "Top-up e-wallet",
    "kategori": "Transfer"
  },
  {
    "kodeUnik": "y1z2a3b4c5d6e7f8",
    "tanggalJam": "2025-07-17T14:05:20Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "9988776655",
    "nikPengirim": "3306051011920005",
    "penyediaJasaPengirim": "CIMB Niaga",
    "lokasiPengirim": "-6.914744, 107.609810",
    "nominalTransaksi": 550000000,
    "pajakAPT": 550000,
    "nikPenerima": "3306051112930006",
    "nomorRekeningPenerima": "1122334455",
    "penyediaJasaPenerima": "BNI",
    "tujuanTransaksi": "Pembelian Material Konstruksi",
    "kategori": "Bisnis",
    "industri": "Konstruksi"
  },
  {
    "kodeUnik": "q9w8e7r6t5y4u3i2",
    "tanggalJam": "2025-07-18T18:20:45Z",
    "kanalTransaksi": "Kartu Debit",
    "nomorRekeningPengirim": "6677889900",
    "nikPengirim": "1202031501750007",
    "penyediaJasaPengirim": "Danamon",
    "lokasiPengirim": "-6.175110, 106.865036",
    "nominalTransaksi": 450000,
    "pajakAPT": 450,
    "nikPenerima": "MERCHANT001",
    "nomorRekeningPenerima": "MERCHANT001",
    "penyediaJasaPenerima": "Supermarket ABC",
    "tujuanTransaksi": "Belanja Bulanan",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "p2o3i4u5y6t7r8e9",
    "tanggalJam": "2025-07-19T11:15:30Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "3344556677",
    "nikPengirim": "1303042005850008",
    "penyediaJasaPengirim": "BTN",
    "lokasiPengirim": "5.556381, 95.320396",
    "nominalTransaksi": 1200000,
    "pajakAPT": 1200,
    "nikPenerima": "PLN001",
    "nomorRekeningPenerima": "PLN001",
    "penyediaJasaPenerima": "PLN",
    "tujuanTransaksi": "Pembayaran Listrik",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "a1s2d3f4g5h6j7k8",
    "tanggalJam": "2025-07-20T22:00:00Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "7788990011",
    "nikPengirim": "3404022509900009",
    "penyediaJasaPengirim": "BSI",
    "lokasiPengirim": "-0.947248, 100.362145",
    "nominalTransaksi": 150000000,
    "pajakAPT": 150000,
    "nikPenerima": "3404022610910010",
    "nomorRekeningPenerima": "2233445566",
    "penyediaJasaPenerima": "Mandiri",
    "tujuanTransaksi": "Pembelian Saham",
    "kategori": "Investasi",
    "industri": "Keuangan & Asuransi"
  },
  {
    "kodeUnik": "z1x2c3v4b5n6m7l8",
    "tanggalJam": "2025-07-21T08:45:10Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "4455667788",
    "nikPengirim": "3202030101880011",
    "penyediaJasaPengirim": "OVO",
    "lokasiPengirim": "-8.670458, 115.212629",
    "nominalTransaksi": 250000,
    "pajakAPT": 250,
    "nikPenerima": "3202030202890012",
    "nomorRekeningPenerima": "8899001122",
    "penyediaJasaPenerima": "DANA",
    "tujuanTransaksi": "Transfer ke teman",
    "kategori": "Transfer"
  },
  {
    "kodeUnik": "k9j8h7g6f5d4s3a2",
    "tanggalJam": "2025-07-22T16:55:55Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "5566778899",
    "nikPengirim": "1101011508950013",
    "penyediaJasaPengirim": "Bank Mega",
    "lokasiPengirim": "-2.548926, 118.014863",
    "nominalTransaksi": 780000000,
    "pajakAPT": 780000,
    "nikPenerima": "1101011609960014",
    "nomorRekeningPenerima": "3344556677",
    "penyediaJasaPenerima": "BCA",
    "tujuanTransaksi": "Pembayaran Impor Mesin Produksi",
    "kategori": "Bisnis",
    "industri": "Manufaktur"
  },
  {
    "kodeUnik": "m1n2b3v4c5x6z7l9",
    "tanggalJam": "2025-07-23T10:10:10Z",
    "kanalTransaksi": "Kartu Kredit",
    "nomorRekeningPengirim": "1122334455",
    "nikPengirim": "3101012001900015",
    "penyediaJasaPengirim": "HSBC",
    "lokasiPengirim": "-7.257472, 112.752089",
    "nominalTransaksi": 3500000,
    "pajakAPT": 3500,
    "nikPenerima": "MERCHANT002",
    "nomorRekeningPenerima": "MERCHANT002",
    "penyediaJasaPenerima": "Toko Elektronik XYZ",
    "tujuanTransaksi": "Pembelian Laptop",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "u1y2t3r4e5w6q7a8",
    "tanggalJam": "2025-07-24T13:30:40Z",
    "kanalTransaksi": "Proprietary Channel",
    "nomorRekeningPengirim": "2233445566",
    "nikPengirim": "3306052503800016",
    "penyediaJasaPengirim": "Perusahaan A",
    "lokasiPengirim": "-6.208763, 106.845599",
    "nominalTransaksi": 8000000,
    "pajakAPT": 8000,
    "nikPenerima": "3306052604810017",
    "nomorRekeningPenerima": "7788990011",
    "penyediaJasaPenerima": "Perusahaan B",
    "tujuanTransaksi": "Pembayaran Jasa Konsultasi",
    "kategori": "Bisnis",
    "industri": "Jasa Profesional"
  },
  {
    "kodeUnik": "i1o2p3a4s5d6f7g8",
    "tanggalJam": "2025-07-25T09:00:15Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "8899001122",
    "nikPengirim": "3202033008850018",
    "penyediaJasaPengirim": "Maybank",
    "lokasiPengirim": "3.595196, 98.672223",
    "nominalTransaksi": 850000,
    "pajakAPT": 850,
    "nikPenerima": "PDAM001",
    "nomorRekeningPenerima": "PDAM001",
    "penyediaJasaPenerima": "PDAM",
    "tujuanTransaksi": "Pembayaran Air",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "l1k2j3h4g5f6d7s9",
    "tanggalJam": "2025-07-26T19:20:25Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "6677889900",
    "nikPengirim": "1202030510920019",
    "penyediaJasaPengirim": "UOB",
    "lokasiPengirim": "-5.147665, 119.432732",
    "nominalTransaksi": 950000000,
    "pajakAPT": 950000,
    "nikPenerima": "1202030611930020",
    "nomorRekeningPenerima": "9988776655",
    "penyediaJasaPenerima": "OCBC NISP",
    "tujuanTransaksi": "Investasi Properti",
    "kategori": "Investasi",
    "industri": "Konstruksi"
  },
  {
    "kodeUnik": "c1v2b3n4m5l6k7j8",
    "tanggalJam": "2025-07-27T12:00:00Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "9988776655",
    "nikPengirim": "1303041002900021",
    "penyediaJasaPengirim": "ShopeePay",
    "lokasiPengirim": "-7.560000, 110.816666",
    "nominalTransaksi": 125000,
    "pajakAPT": 125,
    "nikPenerima": "1303041103910022",
    "nomorRekeningPenerima": "1122334455",
    "penyediaJasaPenerima": "LinkAja",
    "tujuanTransaksi": "Transfer Keluarga",
    "kategori": "Transfer"
  },
  {
    "kodeUnik": "x1z2a3s4d5f6g7h8",
    "tanggalJam": "2025-07-28T07:30:50Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "3344556677",
    "nikPengirim": "3404021504880023",
    "penyediaJasaPengirim": "PermataBank",
    "lokasiPengirim": "-6.402484, 106.794241",
    "nominalTransaksi": 6200000,
    "pajakAPT": 6200,
    "nikPenerima": "3404021605890024",
    "nomorRekeningPenerima": "5566778899",
    "penyediaJasaPenerima": "CIMB Niaga",
    "tujuanTransaksi": "Pembayaran Gaji",
    "kategori": "Gaji",
    "industri": "Jasa Profesional"
  },
  {
    "kodeUnik": "e1r2t3y4u5i6o7p8",
    "tanggalJam": "2025-07-29T21:45:00Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "7788990011",
    "nikPengirim": "1101012009940025",
    "penyediaJasaPengirim": "DBS",
    "lokasiPengirim": "1.144883, 104.025284",
    "nominalTransaksi": 1200000000,
    "pajakAPT": 1200000,
    "nikPenerima": "1101012110950026",
    "nomorRekeningPenerima": "3344556677",
    "penyediaJasaPenerima": "Standard Chartered",
    "tujuanTransaksi": "Akuisisi Perusahaan",
    "kategori": "Bisnis",
    "industri": "Keuangan & Asuransi"
  },
  {
    "kodeUnik": "s1a2d3f4g5h6j7k9",
    "tanggalJam": "2025-07-30T15:15:15Z",
    "kanalTransaksi": "Kartu Debit",
    "nomorRekeningPengirim": "2233445566",
    "nikPengirim": "3202032507820027",
    "penyediaJasaPengirim": "BTPN",
    "lokasiPengirim": "-6.229728, 106.689431",
    "nominalTransaksi": 89000,
    "pajakAPT": 89,
    "nikPenerima": "MERCHANT003",
    "nomorRekeningPenerima": "MERCHANT003",
    "penyediaJasaPenerima": "Restoran Padang Sederhana",
    "tujuanTransaksi": "Makan Siang",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "f1g2h3j4k5l6m7n8",
    "tanggalJam": "2025-07-01T10:20:30Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "1010101010",
    "nikPengirim": "3101010101900028",
    "penyediaJasaPengirim": "Bank DKI",
    "lokasiPengirim": "-6.175392, 106.827153",
    "nominalTransaksi": 500000,
    "pajakAPT": 500,
    "nikPenerima": "3101010202910029",
    "nomorRekeningPenerima": "2020202020",
    "penyediaJasaPenerima": "BRI",
    "tujuanTransaksi": "Transfer antar bank",
    "kategori": "Transfer"
  },
  {
    "kodeUnik": "j1k2l3m4n5b6v7c8",
    "tanggalJam": "2025-07-02T14:45:00Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "3030303030",
    "nikPengirim": "3306051011920030",
    "penyediaJasaPengirim": "Bank Jatim",
    "lokasiPengirim": "-7.265737, 112.748383",
    "nominalTransaksi": 350000000,
    "pajakAPT": 350000,
    "nikPenerima": "3306051112930031",
    "nomorRekeningPenerima": "4040404040",
    "penyediaJasaPenerima": "Bank Jateng",
    "tujuanTransaksi": "Pembayaran Proyek Infrastruktur",
    "kategori": "Bisnis",
    "industri": "Konstruksi"
  },
  {
    "kodeUnik": "v1c2x3z4a5s6d7f8",
    "tanggalJam": "2025-07-03T18:00:15Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "5050505050",
    "nikPengirim": "1202031501750032",
    "penyediaJasaPengirim": "SeaBank",
    "lokasiPengirim": "-8.409518, 115.188919",
    "nominalTransaksi": 95000,
    "pajakAPT": 95,
    "nikPenerima": "1202031602760033",
    "nomorRekeningPenerima": "6060606060",
    "penyediaJasaPenerima": "GoPay",
    "tujuanTransaksi": "Bayar GoFood",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "b1n2m3l4k5j6h7g9",
    "tanggalJam": "2025-07-04T20:10:45Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "7070707070",
    "nikPengirim": "1303042005850034",
    "penyediaJasaPengirim": "Jago",
    "lokasiPengirim": "-6.902474, 107.618782",
    "nominalTransaksi": 2500000,
    "pajakAPT": 2500,
    "nikPenerima": "TELKOM001",
    "nomorRekeningPenerima": "TELKOM001",
    "penyediaJasaPenerima": "Telkom",
    "tujuanTransaksi": "Pembayaran IndiHome",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "g1h2j3k4l5m6n7b8",
    "tanggalJam": "2025-07-05T11:30:00Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "8080808080",
    "nikPengirim": "3404022509900035",
    "penyediaJasaPengirim": "BNI",
    "lokasiPengirim": "-6.200000, 106.816666",
    "nominalTransaksi": 50000000,
    "pajakAPT": 50000,
    "nikPenerima": "3404022610910036",
    "nomorRekeningPenerima": "9090909090",
    "penyediaJasaPenerima": "Mandiri",
    "tujuanTransaksi": "Pembelian Obligasi Pemerintah",
    "kategori": "Investasi",
    "industri": "Keuangan & Asuransi"
  },
  {
    "kodeUnik": "m1k2j3h4g5f6d7s0",
    "tanggalJam": "2025-07-06T09:05:20Z",
    "kanalTransaksi": "Proprietary Channel",
    "nomorRekeningPengirim": "1212121212",
    "nikPengirim": "3202030101880037",
    "penyediaJasaPengirim": "Pertamina",
    "lokasiPengirim": "-6.238333, 106.975833",
    "nominalTransaksi": 150000000,
    "pajakAPT": 150000,
    "nikPenerima": "3202030202890038",
    "nomorRekeningPenerima": "1313131313",
    "penyediaJasaPenerima": "Vendor Logistik",
    "tujuanTransaksi": "Pembayaran Jasa Transportasi BBM",
    "kategori": "Bisnis",
    "industri": "Transportasi"
  },
  {
    "kodeUnik": "n1b2v3c4x5z6a7s9",
    "tanggalJam": "2025-07-07T16:00:00Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "1414141414",
    "nikPengirim": "1101011508950039",
    "penyediaJasaPengirim": "BCA",
    "lokasiPengirim": "-6.175110, 106.865036",
    "nominalTransaksi": 8500000,
    "pajakAPT": 8500,
    "nikPenerima": "1101011609960040",
    "nomorRekeningPenerima": "1515151515",
    "penyediaJasaPenerima": "Mandiri",
    "tujuanTransaksi": "Pembayaran Gaji",
    "kategori": "Gaji",
    "industri": "Perdagangan & Eceran"
  },
  {
    "kodeUnik": "d1f2g3h4j5k6l7m8",
    "tanggalJam": "2025-07-08T13:13:13Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "1616161616",
    "nikPengirim": "3101012001900041",
    "penyediaJasaPengirim": "CIMB Niaga",
    "lokasiPengirim": "-7.257472, 112.752089",
    "nominalTransaksi": 275000000,
    "pajakAPT": 275000,
    "nikPenerima": "3101012102910042",
    "nomorRekeningPenerima": "1717171717",
    "penyediaJasaPenerima": "BNI",
    "tujuanTransaksi": "Pembayaran vendor IT",
    "kategori": "Bisnis",
    "industri": "Teknologi & Informasi"
  },
  {
    "kodeUnik": "l1m2n3b4v5c6x7z9",
    "tanggalJam": "2025-07-09T22:30:00Z",
    "kanalTransaksi": "Kartu Kredit",
    "nomorRekeningPengirim": "1818181818",
    "nikPengirim": "3306052503800043",
    "penyediaJasaPengirim": "Mandiri",
    "lokasiPengirim": "-6.208763, 106.845599",
    "nominalTransaksi": 220000,
    "pajakAPT": 220,
    "nikPenerima": "MERCHANT004",
    "nomorRekeningPenerima": "MERCHANT004",
    "penyediaJasaPenerima": "Toko Buku Gramedia",
    "tujuanTransaksi": "Pembelian buku",
    "kategori": "Belanja Ritel"
  },
  {
    "kodeUnik": "z1x2c3v4b5n6m7l0",
    "tanggalJam": "2025-07-10T08:55:55Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "1919191919",
    "nikPengirim": "3202033008850044",
    "penyediaJasaPengirim": "BRI",
    "lokasiPengirim": "3.595196, 98.672223",
    "nominalTransaksi": 750000,
    "pajakAPT": 750,
    "nikPenerima": "3202033109860045",
    "nomorRekeningPenerima": "2020202020",
    "penyediaJasaPenerima": "BNI",
    "tujuanTransaksi": "Tarik tunai",
    "kategori": "Lainnya"
  },
  {
    "kodeUnik": "a1s2d3f4g5h6j7k1",
    "tanggalJam": "2025-07-11T19:40:10Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "2121212121",
    "nikPengirim": "1202030510920046",
    "penyediaJasaPengirim": "BCA",
    "lokasiPengirim": "-5.147665, 119.432732",
    "nominalTransaksi": 880000000,
    "pajakAPT": 880000,
    "nikPenerima": "1202030611930047",
    "nomorRekeningPenerima": "2222222222",
    "penyediaJasaPenerima": "BRI",
    "tujuanTransaksi": "Pembelian Alat Berat Pertambangan",
    "kategori": "Bisnis",
    "industri": "Pertambangan"
  },
  {
    "kodeUnik": "h1g2f3d4s5a6z7x8",
    "tanggalJam": "2025-07-12T10:10:10Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "2323232323",
    "nikPengirim": "1303041002900048",
    "penyediaJasaPengirim": "DANA",
    "lokasiPengirim": "-7.560000, 110.816666",
    "nominalTransaksi": 300000,
    "pajakAPT": 300,
    "nikPenerima": "1303041103910049",
    "nomorRekeningPenerima": "2424242424",
    "penyediaJasaPenerima": "OVO",
    "tujuanTransaksi": "Transfer",
    "kategori": "Transfer"
  },
  {
    "kodeUnik": "c1v2b3n4m5l6k7j2",
    "tanggalJam": "2025-07-13T12:05:00Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "2525252525",
    "nikPengirim": "3404021504880050",
    "penyediaJasaPengirim": "Mandiri",
    "lokasiPengirim": "-6.402484, 106.794241",
    "nominalTransaksi": 1800000,
    "pajakAPT": 1800,
    "nikPenerima": "ASURANSI01",
    "nomorRekeningPenerima": "ASURANSI01",
    "penyediaJasaPenerima": "Asuransi Sehat",
    "tujuanTransaksi": "Pembayaran Premi Asuransi",
    "kategori": "Pembayaran Tagihan",
    "industri": "Keuangan & Asuransi"
  },
  {
    "kodeUnik": "j1k2l3m4n5b6v7c3",
    "tanggalJam": "2025-07-14T17:30:25Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "2626262626",
    "nikPengirim": "1101012009940051",
    "penyediaJasaPengirim": "Maybank",
    "lokasiPengirim": "1.144883, 104.025284",
    "nominalTransaksi": 420000000,
    "pajakAPT": 420000,
    "nikPenerima": "1101012110950052",
    "nomorRekeningPenerima": "2727272727",
    "penyediaJasaPenerima": "DBS",
    "tujuanTransaksi": "Pembayaran Ekspor-Impor",
    "kategori": "Bisnis",
    "industri": "Perdagangan & Eceran"
  },
  {
    "kodeUnik": "x1z2c3v4b5n6m7l4",
    "tanggalJam": "2025-07-15T23:59:59Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "2828282828",
    "nikPengirim": "3202032507820053",
    "penyediaJasaPengirim": "GoPay",
    "lokasiPengirim": "-6.229728, 106.689431",
    "nominalTransaksi": 50000,
    "pajakAPT": 50,
    "nikPenerima": "3202032608830054",
    "nomorRekeningPenerima": "2929292929",
    "penyediaJasaPenerima": "DANA",
    "tujuanTransaksi": "Transfer Uang Kaget",
    "kategori": "Lainnya"
  },
  {
    "kodeUnik": "q1w2e3r4t5y6u7i8",
    "tanggalJam": "2025-07-16T11:11:11Z",
    "kanalTransaksi": "Internet Banking",
    "nomorRekeningPengirim": "3030303030",
    "nikPengirim": "3101010101900055",
    "penyediaJasaPengirim": "BCA",
    "lokasiPengirim": "-6.175392, 106.827153",
    "nominalTransaksi": 100000000,
    "pajakAPT": 100000,
    "nikPenerima": "3101010202910056",
    "nomorRekeningPenerima": "3131313131",
    "penyediaJasaPenerima": "Sekuritas ABC",
    "tujuanTransaksi": "Top Up RDN",
    "kategori": "Investasi",
    "industri": "Keuangan & Asuransi"
  },
  {
    "kodeUnik": "i1o2p3a4s5d6f7g9",
    "tanggalJam": "2025-07-17T08:08:08Z",
    "kanalTransaksi": "RTGS",
    "nomorRekeningPengirim": "3232323232",
    "nikPengirim": "3306051011920057",
    "penyediaJasaPengirim": "Bank of China",
    "lokasiPengirim": "-6.200000, 106.816666",
    "nominalTransaksi": 1500000000,
    "pajakAPT": 1500000,
    "nikPenerima": "3306051112930058",
    "nomorRekeningPenerima": "3333333333",
    "penyediaJasaPenerima": "HSBC",
    "tujuanTransaksi": "Financing Proyek Manufaktur",
    "kategori": "Bisnis",
    "industri": "Manufaktur"
  },
  {
    "kodeUnik": "g1f2d3s4a5z6x7c8",
    "tanggalJam": "2025-07-18T14:20:35Z",
    "kanalTransaksi": "ATM",
    "nomorRekeningPengirim": "3434343434",
    "nikPengirim": "1202031501750059",
    "penyediaJasaPengirim": "BTN",
    "lokasiPengirim": "-7.265737, 112.748383",
    "nominalTransaksi": 2000000,
    "pajakAPT": 2000,
    "nikPenerima": "KAMPUS01",
    "nomorRekeningPenerima": "KAMPUS01",
    "penyediaJasaPenerima": "Universitas ABC",
    "tujuanTransaksi": "Pembayaran UKT",
    "kategori": "Pembayaran Tagihan"
  },
  {
    "kodeUnik": "v1b2n3m4l5k6j7h9",
    "tanggalJam": "2025-07-19T10:00:00Z",
    "kanalTransaksi": "Mobile Banking",
    "nomorRekeningPengirim": "3535353535",
    "nikPengirim": "1303042005850060",
    "penyediaJasaPengirim": "BRI",
    "lokasiPengirim": "-8.409518, 115.188919",
    "nominalTransaksi": 6000000,
    "pajakAPT": 6000,
    "nikPenerima": "3404022509900061",
    "nomorRekeningPenerima": "3636363636",
    "penyediaJasaPenerima": "BCA",
    "tujuanTransaksi": "Pembayaran Gaji Asisten Rumah Tangga",
    "kategori": "Gaji"
  }
];


// =================================================================
// Combined and Exported Dataset
// =================================================================

const generatedTransactions = generateTransactions(1000);

export const MOCK_TRANSACTIONS: Transaction[] = [...originalTransactions, ...generatedTransactions];
