
import React from 'react';

export type Industry = 'Keuangan & Asuransi' | 'Teknologi & Informasi' | 'Perdagangan & Eceran' | 'Konstruksi' | 'Manufaktur' | 'Jasa Profesional' | 'Pertambangan' | 'Transportasi' | 'Lainnya';

export interface Transaction {
  kodeUnik: string;
  tanggalJam: string;
  kanalTransaksi: string;
  nomorRekeningPengirim: string;
  nikPengirim: string;
  penyediaJasaPengirim: string;
  lokasiPengirim: string;
  nominalTransaksi: number;
  pajakAPT: number;
  nikPenerima: string;
  nomorRekeningPenerima: string;
  penyediaJasaPenerima: string;
  tujuanTransaksi: string;
  kategori: 'Gaji' | 'Belanja Ritel' | 'Pembayaran Tagihan' | 'Transfer' | 'Investasi' | 'Bisnis' | 'Lainnya';
  industri?: Industry;
}

export interface Stat {
    title: string;
    value: string;
    change?: string;
    changeType?: 'increase' | 'decrease';
    icon: React.ReactNode;
}

export interface Insight {
  title: string;
  description: string;
  type: 'anomaly' | 'trend' | 'observation';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
