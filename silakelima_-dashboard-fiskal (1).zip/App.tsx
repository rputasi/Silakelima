import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import TaxAnalytics from './components/TaxAnalytics';
import AIPage from './components/AIPage';
import TransactionsPage from './components/TransactionsPage';
import BottomNav from './components/BottomNav';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState('dashboard');
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);


  return (
    <div className="flex h-screen bg-dark-bg text-dark-text-primary font-sans">
      {isMobile ? (
        <BottomNav activeView={activeView} setActiveView={setActiveView} />
      ) : (
        <Sidebar activeView={activeView} setActiveView={setActiveView} />
      )}
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className={`flex-1 overflow-x-hidden overflow-y-auto ${activeView === 'ai-assistant' ? 'p-0' : 'p-4 md:p-6'} ${isMobile ? 'pb-20' : ''}`}>
          {activeView === 'dashboard' && <Dashboard />}
          {activeView === 'transactions' && <TransactionsPage />}
          {activeView === 'tax-analytics' && <TaxAnalytics />}
          {activeView === 'ai-assistant' && <AIPage />}
        </main>
      </div>
    </div>
  );
};

export default App;