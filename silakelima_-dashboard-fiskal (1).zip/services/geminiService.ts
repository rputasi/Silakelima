

import { GoogleGenAI, Type, Chat } from "@google/genai";
import type { Transaction, Insight, Industry } from '../types';

// IMPORTANT: Do not expose the API key in the frontend for a real application.
// This is for demonstration purposes only, assuming the key is available in the environment.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key is not set. AI Assistant will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "mock-key" });

const simplifyTransactions = (transactions: Transaction[]) => {
    return transactions.map(t => ({
        kanal: t.kanalTransaksi,
        nominal: t.nominalTransaksi,
        pajak: t.pajakAPT,
        tujuan: t.tujuanTransaksi,
        pengirim: t.penyediaJasaPengirim,
        penerima: t.penyediaJasaPenerima,
        kategori: t.kategori,
        industri: t.industri,
    }));
};

export const callGemini = async (query: string, transactions: Transaction[]): Promise<string> => {
    if (!API_KEY) {
        return Promise.resolve("Fitur AI tidak aktif karena API Key tidak ditemukan. Silakan atur variabel lingkungan API_KEY.");
    }

    const simplifiedTransactions = simplifyTransactions(transactions);

    const prompt = `
Anda adalah seorang analis keuangan ahli untuk Kementerian Keuangan Indonesia, dengan nama SilaKelima AI.
Berdasarkan data transaksi berikut (dalam format JSON), jawab pertanyaan pengguna dengan analisis yang tajam, ringkas, dan profesional dalam Bahasa Indonesia.
Fokus pada identifikasi tren, anomali, atau wawasan yang relevan untuk reformasi fiskal.
Jangan hanya mengulang data, berikan interpretasi.

Data Transaksi:
\`\`\`json
${JSON.stringify(simplifiedTransactions, null, 2)}
\`\`\`

Pertanyaan Pengguna: "${query}"

Analisis Anda:
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.3,
                topP: 0.9,
            }
        });
        
        return response.text || '';
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Gagal berkomunikasi dengan Gemini API.");
    }
};

const insightSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            title: {
                type: Type.STRING,
                description: 'A short, descriptive title for the insight (max 5 words) in Indonesian.',
            },
            description: {
                type: Type.STRING,
                description: 'A concise explanation of the insight or anomaly found in the data (max 25 words) in Indonesian.',
            },
            type: {
                type: Type.STRING,
                enum: ['anomaly', 'trend', 'observation'],
                description: 'The category of the insight.',
            },
        },
        required: ['title', 'description', 'type'],
    },
};

export const getAIInsights = async (transactions: Transaction[]): Promise<Insight[]> => {
    if (!API_KEY) {
        return Promise.resolve([
            { title: "Fitur AI Tidak Aktif", description: "API Key tidak ditemukan. Wawasan otomatis tidak dapat dibuat.", type: "anomaly" }
        ]);
    }

    const simplifiedTransactions = simplifyTransactions(transactions);

    const prompt = `
Anda adalah seorang analis keuangan dan detektif fraud untuk Kementerian Keuangan Indonesia.
Berdasarkan data transaksi berikut, identifikasi 3 wawasan, tren, atau anomali paling signifikan yang relevan untuk pengawasan fiskal.
Fokus pada hal-hal yang tidak biasa, pola yang muncul, atau data agregat yang menarik.
Sajikan temuan Anda dalam format JSON yang diminta.

Data Transaksi:
\`\`\`json
${JSON.stringify(simplifiedTransactions, null, 2)}
\`\`\`
`;
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: insightSchema,
                temperature: 0.5,
            },
        });

        const jsonText = response.text;
        if (!jsonText) {
            console.error("AI insights response text is empty or undefined.", response);
            throw new Error("AI response is empty.");
        }
        
        const insights = JSON.parse(jsonText.trim());
        return insights as Insight[];
    } catch (error) {
        console.error("Error getting AI insights:", error);
        throw new Error("Gagal menghasilkan wawasan dari AI.");
    }
};


const classificationDetailsSchema = {
    type: Type.OBJECT,
    properties: {
        category: {
            type: Type.STRING,
            enum: ['Gaji', 'Belanja Ritel', 'Pembayaran Tagihan', 'Transfer', 'Investasi', 'Bisnis', 'Lainnya'],
            description: "Kategori umum dari transaksi."
        },
        industry: {
            type: Type.STRING,
            enum: ['Keuangan & Asuransi', 'Teknologi & Informasi', 'Perdagangan & Eceran', 'Konstruksi', 'Manufaktur', 'Jasa Profesional', 'Pertambangan', 'Transportasi', 'Lainnya'],
            description: "Klasifikasi industri yang relevan. Jika tidak berlaku, gunakan 'Lainnya'."
        }
    },
    required: ['category', 'industry'],
};

export const classifyTransactionDetails = async (purpose: string): Promise<{ category: string, industry: Industry }> => {
    const fallbackResult = { category: 'Lainnya', industry: 'Lainnya' as Industry };
    if (!API_KEY) {
        return fallbackResult;
    }

    const prompt = `
Anda adalah seorang analis keuangan ahli. Klasifikasikan tujuan transaksi berikut ke dalam 'Kategori' dan 'Industri' yang paling sesuai dari pilihan yang diberikan.
Tujuan Transaksi: "${purpose}"
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: classificationDetailsSchema,
            },
        });
        
        const jsonText = response.text;
        if (!jsonText) {
            console.error("AI classification response text is empty or undefined.", response);
            return fallbackResult;
        }

        const json = JSON.parse(jsonText.trim());
        return {
            category: json.category || 'Lainnya',
            industry: json.industry || 'Lainnya',
        };
    } catch (error) {
        console.error('Error classifying transaction:', error);
        return fallbackResult;
    }
};

const systemInstruction = `
Anda adalah seorang analis keuangan ahli untuk Kementerian Keuangan Indonesia, dengan nama SilaKelima AI.
Anda memiliki akses ke kumpulan data transaksi keuangan. Gunakan data ini untuk menjawab pertanyaan pengguna dengan analisis yang tajam, ringkas, dan profesional dalam Bahasa Indonesia.
Fokus pada identifikasi tren, anomali, atau wawasan yang relevan untuk reformasi fiskal.
Jangan hanya mengulang data, berikan interpretasi. Jadilah proaktif dan tawarkan wawasan tambahan jika memungkinkan.
Format respons Anda menggunakan markdown untuk keterbacaan yang lebih baik.
Data transaksi yang tersedia memiliki skema berikut:
- kodeUnik: string
- tanggalJam: string
- kanalTransaksi: string
- nominalTransaksi: number
- pajakAPT: number
- tujuanTransaksi: string
- kategori: 'Gaji' | 'Belanja Ritel' | 'Pembayaran Tagihan' | 'Transfer' | 'Investasi' | 'Bisnis' | 'Lainnya'
- industri: 'Keuangan & Asuransi' | 'Teknologi & Informasi' | 'Perdagangan & Eceran' | 'Konstruksi' | 'Manufaktur' | 'Jasa Profesional' | 'Pertambangan' | 'Transportasi' | 'Lainnya'
`;

export const createChat = (transactions: Transaction[]): Chat => {
    if (!API_KEY) {
        throw new Error("Gemini API key is not set. AI Assistant tidak akan bekerja.");
    }

    const simplifiedTransactions = simplifyTransactions(transactions);

    const history = [
        {
            role: "user",
            parts: [{ text: `Ini adalah data transaksi yang akan kita analisis:\n\`\`\`json\n${JSON.stringify(simplifiedTransactions.slice(0, 20), null, 2)}\n\`\`\`` }],
        },
        {
            role: "model",
            parts: [{ text: "Baik, saya telah menerima dan memahami data transaksi. Saya siap membantu Anda menganalisisnya. Apa yang ingin Anda ketahui?" }],
        }
    ];

    const chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        history: history,
        config: {
            systemInstruction: systemInstruction,
            temperature: 0.5,
        }
    });

    return chat;
};